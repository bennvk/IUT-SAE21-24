import easyocr
import cv2

# Initialise EasyOCR
reader = easyocr.Reader(['fr'], gpu=False)

def recognize_plate_from_frame(frame):
    # Convertit l'image en niveaux de gris
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Lecture OCR
    results = reader.readtext(gray)

    plates = []
    for bbox, text, conf in results:
        if 4 <= len(text) <= 10 and any(c.isdigit() for c in text):
            plates.append((text.upper(), conf))

    if plates:
        plates.sort(key=lambda x: x[1], reverse=True)
        return plates[0][0]
    return None

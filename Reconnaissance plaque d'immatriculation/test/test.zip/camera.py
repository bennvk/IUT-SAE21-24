import cv2
from config import CAMERA_SOURCE

def get_camera_stream():
    cap = cv2.VideoCapture(CAMERA_SOURCE)
    if not cap.isOpened():
        raise Exception("Unable to connect to IP camera.")
    return cap

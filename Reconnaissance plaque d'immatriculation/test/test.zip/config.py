CAMERA_SOURCE = 0
SAVE_IMAGES = True # True pour debug ou historique
DB_PATH = "plates.db"

import sqlite3
from config import DB_PATH

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS plates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plate TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                image_path TEXT
            )
        ''')

def insert_plate(plate, image_path):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("INSERT INTO plates (plate, image_path) VALUES (?, ?)", (plate, image_path))

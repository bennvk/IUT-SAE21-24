import cv2
import time
from camera import get_camera_stream
from db import init_db, insert_plate
from alpr import recognize_plate_from_frame
from config import SAVE_IMAGES
import os

def main():
    init_db()
    cap = get_camera_stream()
    os.makedirs("images", exist_ok=True)

    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        # Reconnaissance directe depuis l'image
        plate = recognize_plate_from_frame(frame)
        if plate:
            print(f"[DETECTED] Plaque : {plate}")

        time.sleep(1)  # Capture toutes les 1 seconde

if __name__ == "__main__":
    main()
